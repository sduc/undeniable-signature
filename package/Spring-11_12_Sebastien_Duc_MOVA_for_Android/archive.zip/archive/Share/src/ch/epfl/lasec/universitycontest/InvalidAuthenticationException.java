package ch.epfl.lasec.universitycontest;

public class InvalidAuthenticationException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
