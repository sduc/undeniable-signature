#!/bin/sh

cd Share;ant;cd ..;
cd Server;ant;cd ..;
cd UniversityContest;ant;cd ..;

